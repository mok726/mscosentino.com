VERSION 5.00
Begin VB.Form Arbolito 
   BorderStyle     =   3  'Fixed Dialog
   ClientHeight    =   1620
   ClientLeft      =   150
   ClientTop       =   150
   ClientWidth     =   4275
   ControlBox      =   0   'False
   Icon            =   "Arbolito.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   1620
   ScaleWidth      =   4275
   ShowInTaskbar   =   0   'False
   StartUpPosition =   2  'CenterScreen
   Begin VB.CommandButton OK 
      Caption         =   "&OK"
      Height          =   495
      Left            =   1320
      TabIndex        =   8
      Top             =   1080
      Width           =   1455
   End
   Begin VB.Timer Timer1 
      Interval        =   200
      Left            =   3720
      Top             =   2280
   End
   Begin VB.PictureBox Picture1 
      Height          =   615
      Index           =   4
      Left            =   3120
      Picture         =   "Arbolito.frx":030A
      ScaleHeight     =   555
      ScaleWidth      =   555
      TabIndex        =   4
      Top             =   2160
      Width           =   615
   End
   Begin VB.PictureBox Picture1 
      Height          =   615
      Index           =   3
      Left            =   2400
      Picture         =   "Arbolito.frx":0614
      ScaleHeight     =   555
      ScaleWidth      =   555
      TabIndex        =   3
      Top             =   2160
      Width           =   615
   End
   Begin VB.PictureBox Picture1 
      Height          =   615
      Index           =   2
      Left            =   1680
      Picture         =   "Arbolito.frx":091E
      ScaleHeight     =   555
      ScaleWidth      =   555
      TabIndex        =   2
      Top             =   2145
      Width           =   615
   End
   Begin VB.PictureBox Picture1 
      Height          =   615
      Index           =   1
      Left            =   960
      Picture         =   "Arbolito.frx":0C28
      ScaleHeight     =   555
      ScaleWidth      =   555
      TabIndex        =   1
      Top             =   2160
      Width           =   615
   End
   Begin VB.PictureBox Picture1 
      Height          =   615
      Index           =   0
      Left            =   240
      Picture         =   "Arbolito.frx":0F32
      ScaleHeight     =   555
      ScaleWidth      =   555
      TabIndex        =   0
      Top             =   2160
      Width           =   615
   End
   Begin VB.Label Label3 
      Caption         =   "marianok@technologist.com"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   14.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FF0000&
      Height          =   375
      Left            =   120
      TabIndex        =   7
      Top             =   600
      Width           =   3975
   End
   Begin VB.Label Label2 
      Alignment       =   2  'Center
      Caption         =   "Le Desea"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   120
      TabIndex        =   6
      Top             =   240
      Width           =   3975
   End
   Begin VB.Label Label1 
      Alignment       =   2  'Center
      Caption         =   "Fel�z Navidad y Pr�spero a�o Nuevo"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   120
      TabIndex        =   5
      Top             =   0
      Width           =   4095
   End
   Begin VB.Menu mnuShell 
      Caption         =   "Opciones"
      Begin VB.Menu mnuOff 
         Caption         =   "&Apagado"
      End
      Begin VB.Menu mnuOn 
         Caption         =   "&Encendido"
         Checked         =   -1  'True
      End
      Begin VB.Menu mnurelleno 
         Caption         =   "-"
      End
      Begin VB.Menu mnuClose 
         Caption         =   "&Cerrar"
         Shortcut        =   ^X
      End
      Begin VB.Menu relleno2 
         Caption         =   "-"
      End
      Begin VB.Menu mnuAcerca 
         Caption         =   "Acerca de ..."
      End
   End
End
Attribute VB_Name = "Arbolito"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Dim I As Integer


Private Sub Command1_Click()

End Sub

Private Sub mnuAcerca_Click()
    Me.Show
    'Me.WindowState = 0
    
End Sub

Private Sub mnuClose_Click()
   Shell_NotifyIcon NIM_DELETE, t
   End
End Sub

Private Sub mnuOff_Click()
   mnuOff.Checked = True
   mnuOn.Checked = False
   I = 0
   t.hIcon = Picture1(I).Picture
   t.szTip = "Fel�z Navidad, les desea marianok" & Chr$(0)
   Shell_NotifyIcon NIM_MODIFY, t

End Sub

Private Sub mnuOn_Click()
   mnuOn.Checked = True
   mnuOff.Checked = False
   t.szTip = "Fel�z Navidad, les desea marianok" & Chr$(0)
End Sub

Private Sub OK_Click()
    'Me.WindowState = 1
    Me.Hide
    
End Sub

Private Sub Picture1_MouseMove _
            (Index As Integer, _
            Button As Integer, _
             Shift As Integer, _
             X As Single, Y As Single)
    
    If Hex(X) = "1E3C" Then
        Arbolito.PopupMenu Arbolito.mnuShell
    End If

End Sub

Private Sub Form_Load()

    I = 0
    t.cbSize = Len(t)
    t.hWnd = Picture1(0).hWnd
    t.uID = 1&
    t.uFlags = NIF_MESSAGE Or _
                     NIF_ICON Or _
                     NIF_TIP
    
    t.uCallbackMessage = WM_MOUSEMOVE

    t.hIcon = Picture1(I).Picture
    t.szTip = "Muy Fel�z Navidad y Prospero A�o Nuevo, les desea marianok" & Chr$(0)
    Shell_NotifyIcon NIM_ADD, t
    Me.Hide
End Sub


Private Sub Timer1_Timer()
    If mnuOn.Checked Then
        Rem Call NotifyIcon_Change(, " ")
        I = I + 1: If I > 4 Then I = 0
        t.hIcon = Picture1(I).Picture
        Shell_NotifyIcon NIM_MODIFY, t
    End If
End Sub
